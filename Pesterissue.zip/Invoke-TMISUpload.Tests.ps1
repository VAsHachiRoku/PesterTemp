# If want to see more details when running pester
# $PesterPreference = [PesterConfiguration]::Default
# $PesterPreference.Output.Verbosity = 'Detailed'
#
# Online References
# https://pester.dev/docs/usage/data-driven-tests#beforediscovery
# https://stackoverflow.com/questions/65417696/how-to-run-pester-quickly-with-output-detailed-in-vscode#:~:text=If%20you%20go%20to%20the%20Settings%20of%20VSCode,the%20%24PesterPreference%20variable%20which%20it%20uses%20by%20default.

BeforeDiscovery {
    #Shared Variables
    $Tier0ScriptsPath = "C:\Tier0Scripts\"
    $TMISPath = "C:\TMIS\Upload\"

    #Context variables for checking the count of CSV and Uploads match
    $Tier1CsvCount = Import-Csv -Path "$Tier0ScriptsPath\Tier1MemberServers.CSV" | Measure-Object
    $UploadFoldersCount = Get-ChildItem -Path $TMISPath -Directory | Measure-Object

    #Context variables for checking the specific files in each directory in the upload folder
    $TMISUploadFolders = Get-ChildItem -Path $TMISPath -Directory
    $specificFilePatterns = @("GPRESULT-HTM-*.html", "GPRESULT-XML-*.xml")
    $CombinedFilePaths = @()
    foreach ($ParentFolder in $TMISUploadFolders) {
        foreach ($filePattern in $specificFilePatterns) {
            $filePath = Join-Path -Path $parentFolder.FullName -ChildPath $filePattern
            $CombinedFilePaths += $filePath
        }
    }

}

Describe "Testing TMIS Upload Folders and Child Files" {

    Context "Testing Current file in Combine files paths" {
        It "Upload Directory Count should match CSV Count" {
            $UploadFoldersCount.Count | Should -Be $Tier1CsvCount.Count
        }
    }

    Context "Testing Current file in Combine files paths" -ForEach $CombinedFilePaths {
        BeforeAll  {
            # Renaming the automatic $_ variable to $file
            # to make it easier to work with
            $file = $_
        }

        It "The <file> should exist" {
            Test-Path -Path $file | Should -BeTrue
        }
    }
}